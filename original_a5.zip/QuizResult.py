#import Persist
from random import *
    

class QuizResult:
    

    ## This dictionary will hold all of the quiz attempts and their relevant information as a dictionary where the keys
    ##are the quiz names and the values are lists containing [studentemail, list of questions, list of lists of choices, list
    ##of responses and list of correct answers. There will be a list for each attempt.
    _quiz_dict = {}

    ##This dictionary will look like the previous; the only difference will be that the values of its list will have an additional
    ##value at the end; the grade as a floating point number. 
    _quiz_graded = {}

    def __init__(self):
        """This initializes the quiz result object."""

            

    def add_quiz_attempts(self,attempt_dict):
        """This iterates over the quiz attempts dictionary and adds the information to the quiz result object's dictionary."""
        self._quiz_dict['test'] = 10

    def get_all_attempts(self):
        """This function returns the dictionary member variable that will contain all of our graded quiz attempts"""

        return self._quiz_graded


        
    def grade(self,attempt_dict):
        """This function will grade the quiz attempts and then store the highest scored attempt, along with all of its information, in the dictionary member variable."""
        self._quiz_graded['Quiz 1'] = ['bnm343@mun.ca',['question1'],[['choice a', 'choice b']],['A','A'],['A','B']]
        
    

    def ins_class_part(self,quizname):
        """This function will calculate the class participation and return it as a string."""
        
        return '56.8'

    def ins_class_avg(self,quizname):
        """This function will calculate the class average of a quiz and return it as a float."""
        x = randint(0,100)
        return float(x)

    def ins_class_hist(self,quizname):
        """This function will return the grade distribution histogram as a dictionary with increments as keys and number of students as values."""

        return {'0 - 9':5,'10 - 19': 4,'20 - 29': 2,'30 - 39': 6,'40 - 49': 2,'50 - 59': 1,'60 - 69': 7,'70 - 79': 11,'80 - 89': 5,'90 - 100': 2}

    def ins_class_attempts(self,quizname):
        """This function will return the number of attempts by students on a given quiz as a list"""
        return ['John - 2','Mary - 4','Jenny - 1']

    def ins_student_grades(self,studentemail):
        """This function will return a list of strings containing the grades of a given student on all of their quizzes."""

        return ['Quiz 1 = Attempt 1 - 88, Attempt 2 - 72','Quiz 2 = Attempt 1 - 90']

    def stu_quiz_grades(self,studentemail):
        """This function will return a list of strings containing the summary of the student's grades by quiz."""
        

        return ['Quiz 1 = Attempt 1 - 88, Attempt 2 - 72','Quiz 2 = Attempt 1 - 90']

    def stu_quiz_detailed(self,studentemail,quizname):
        """This function will return a string with the breakdown of a given quiz by a given student."""

        return 'Quiz 1 = Attempt 1 - 93, Attempt 2 - 75'

        
#help(QuizResult)


        
